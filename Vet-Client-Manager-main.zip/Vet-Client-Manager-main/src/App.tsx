import { useState } from "react";
import type { View } from "./types";
import Welcome from "./views/Welcome";
import Menu from "./views/Menu";
import AddClient from "./views/AddClient";
import ListClients from "./views/ListClients";
import AddVisit from "./views/AddVisit.tsx";
import ListVisits from "./views/ListVisits.tsx";

export default function App() {
    const [view, setView] = useState<View>("welcome");
    const go = (v: View) => setView(v);

    switch (view) {
        case "welcome":
            return <Welcome go={go} />;
        case "menu":
            return <Menu go={go} />;
        case "add-client":
            return <AddClient go={go} />;
        case "list-clients":
            return <ListClients go={go} />;
        case "add-visit":
            return <AddVisit go={go} />;
        case "list-visits":
            return <ListVisits go={go} />;
        default:
            return (
                <div className="flex min-h-screen items-center justify-center bg-white">
                    <div className="text-center">
                        <h2 className="text-3xl font-semibold text-gray-900">Coming soon</h2>
                        <p className="mt-2 text-gray-600">We’ll build this view next.</p>
                        <button
                            onClick={() => go("menu")}
                            className="mt-6 rounded-xl border px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                            Back to menu
                        </button>
                    </div>
                </div>
            );
    }
}
