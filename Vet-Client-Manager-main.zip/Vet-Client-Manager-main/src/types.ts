export type View =
    | "welcome"
    | "menu"
    | "add-client"
    | "list-clients"
    | "add-visit"
    | "list-visits";

export interface Client {
    id: string;
    ownerName: string;
    petType: string;
    breed: string;
    dob: string;        // ISO date
    createdAt: string;  // ISO date-time
}

export interface Visit {
    id: string;
    clientId: string;   // ↔ relation to Client.id
    date: string;       // ISO date
    reason: string;
    notes?: string;
    cost?: number;      // optional
    createdAt: string;  // ISO date-time
}
