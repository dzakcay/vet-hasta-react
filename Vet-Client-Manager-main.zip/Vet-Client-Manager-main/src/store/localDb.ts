import type { Client, Visit } from "../types";

const CLIENTS_KEY = "vcm.clients";
const VISITS_KEY = "vcm.visits";

function readJson<T>(key: string, fallback: T): T {
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return fallback;
        return JSON.parse(raw) as T;
    } catch {
        return fallback;
    }
}

function writeJson<T>(key: string, value: T) {
    localStorage.setItem(key, JSON.stringify(value));
}

/* Clients */
export function getClients(): Client[] {
    return readJson<Client[]>(CLIENTS_KEY, []);
}

export function addClient(input: Omit<Client, "id" | "createdAt">): Client {
    const newClient: Client = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        createdAt: new Date().toISOString(),
        ...input,
    };
    const all = getClients();
    all.push(newClient);
    writeJson(CLIENTS_KEY, all);
    return newClient;
}

/* Visits */
export function getVisits(): Visit[] {
    return readJson<Visit[]>(VISITS_KEY, []);
}

export function addVisit(input: Omit<Visit, "id" | "createdAt">): Visit {
    const newVisit: Visit = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        createdAt: new Date().toISOString(),
        ...input,
    };
    const all = getVisits();
    all.push(newVisit);
    writeJson(VISITS_KEY, all);
    return newVisit;
}

export function getVisitsByClient(clientId: string): Visit[] {
    return getVisits().filter((v) => v.clientId === clientId);
}
