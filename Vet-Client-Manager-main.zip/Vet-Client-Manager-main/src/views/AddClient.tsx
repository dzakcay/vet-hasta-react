import { useState } from "react";
import type { View } from "../types";
import { addClient } from "../store/localDb";
import Shell from "../components/Shell";

export default function AddClient({ go }: { go: (v: View) => void }) {
    const [ownerName, setOwnerName] = useState("");
    const [petType, setPetType] = useState("");
    const [breed, setBreed] = useState("");
    const [dob, setDob] = useState("");
    const [saving, setSaving] = useState(false);
    const [savedId, setSavedId] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    function validate() {
        if (!ownerName.trim()) return "Owner's name is required.";
        if (!petType.trim()) return "Type of pet is required.";
        if (!breed.trim()) return "Breed is required.";
        if (!dob) return "Date of birth is required.";
        return null;
    }

    function onSubmit(e: React.FormEvent) {
        e.preventDefault();
        setError(null);
        const v = validate();
        if (v) return setError(v);
        setSaving(true);
        try {
            addClient({ ownerName: ownerName.trim(), petType: petType.trim(), breed: breed.trim(), dob });
            setSavedId("ok-" + Date.now());
            setOwnerName(""); setPetType(""); setBreed(""); setDob("");
        } catch {
            setError("Failed to save. Please try again.");
        } finally {
            setSaving(false);
        }
    }

    return (
        <Shell
            title="Add new client"
            subtitle="Enter the pet details below; records are saved locally on this device."
            onBack={() => go("menu")}
        >
            <form className="mx-auto w-full max-w-xl space-y-4" onSubmit={onSubmit}>
                <Field label="Owner's name" required>
                    <input
                        type="text"
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        value={ownerName}
                        onChange={(e) => setOwnerName(e.target.value)}
                        placeholder="e.g., Jane Doe"
                    />
                </Field>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <Field label="Type of pet" required>
                        <input
                            type="text"
                            className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                            value={petType}
                            onChange={(e) => setPetType(e.target.value)}
                            placeholder="Dog, Cat, …"
                        />
                    </Field>
                    <Field label="Breed" required>
                        <input
                            type="text"
                            className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                            value={breed}
                            onChange={(e) => setBreed(e.target.value)}
                            placeholder="e.g., Golden Retriever"
                        />
                    </Field>
                </div>

                <Field label="Date of birth" required>
                    <input
                        type="date"
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        max={new Date().toISOString().slice(0, 10)}
                    />
                </Field>

                {error && <p className="text-sm text-red-600">{error}</p>}
                {savedId && (
                    <div className="rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-700">
                        Saved successfully.
                    </div>
                )}

                <div className="pt-2 flex items-center gap-3">
                    <button
                        type="submit"
                        disabled={saving}
                        className="rounded-xl bg-blue-600 px-4 py-2 font-medium text-white shadow-sm transition hover:bg-blue-700 active:scale-[0.99] disabled:opacity-60"
                    >
                        {saving ? "Saving..." : "Submit"}
                    </button>
                    <button
                        type="button"
                        onClick={() => go("menu")}
                        className="rounded-xl border px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </Shell>
    );
}

function Field({
                   label,
                   required,
                   children,
               }: {
    label: string;
    required?: boolean;
    children: React.ReactNode;
}) {
    return (
        <label className="block">
      <span className="mb-1 block text-sm font-medium text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </span>
            {children}
        </label>
    );
}
