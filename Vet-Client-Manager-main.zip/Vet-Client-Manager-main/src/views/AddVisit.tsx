import {useEffect, useMemo, useState} from "react";
import type {View} from "../types";
import {addVisit, getClients} from "../store/localDb";
import Shell from "../components/Shell";

export default function AddVisit({go}: { go: (v: View) => void }) {
    const [clients, setClients] = useState(() => getClients());
    const [clientId, setClientId] = useState("");
    const [date, setDate] = useState("");
    const [reason, setReason] = useState("");
    const [notes, setNotes] = useState("");
    const [cost, setCost] = useState<string>(""); // keep as string for input control
    const [saving, setSaving] = useState(false);
    const [savedId, setSavedId] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    // keep client list fresh if added elsewhere
    useEffect(() => {
        const onStorage = (e: StorageEvent) => {
            if (e.key === "vcm.clients") setClients(getClients());
        };
        window.addEventListener("storage", onStorage);
        return () => window.removeEventListener("storage", onStorage);
    }, []);

    const sortedClients = useMemo(
        () =>
            [...clients].sort((a, b) =>
                a.ownerName.localeCompare(b.ownerName, undefined, {sensitivity: "base"})
            ),
        [clients]
    );

    useEffect(() => {
        if (savedId) {
            const t1 = setTimeout(() => setSavedId(null), 2500);
            const t2 = setTimeout(() => setError(null), 2500);
            return () => {
                clearTimeout(t1);
                clearTimeout(t2);
            }
        }
    }, [savedId, error]);

    function validate() {
        if (!clients.length) return "No clients found. Please add a client first.";
        if (!clientId) return "Please select a client.";
        if (!date) return "Visit date is required.";
        if (!reason.trim()) return "Reason is required.";
        // optional: validate cost is a positive number
        if (cost && isNaN(Number(cost))) return "Cost must be a number (e.g., 125.50).";
        return null;
    }

    function onSubmit(e: React.FormEvent) {
        e.preventDefault();
        setError(null);
        const v = validate();
        if (v) {
            setError(v);
            return;
        }
        setSaving(true);
        try {
            addVisit({
                clientId,
                date,
                reason: reason.trim(),
                notes: notes.trim() || undefined,
                cost: cost ? Number(cost) : undefined,
            });
            setSavedId("ok-" + Date.now());
            // clear form except client (keep selected to add multiple visits quickly)
            setDate("");
            setReason("");
            setNotes("");
            setCost("");
        } catch {
            setError("Failed to save. Please try again.");
        } finally {
            setSaving(false);
        }
    }

    return (
        <Shell
            title="Add new visit"
            subtitle="Link the visit to a client; data is saved locally."
            onBack={() => go("menu")}
        >
            <form className="mx-auto w-full max-w-xl space-y-4" onSubmit={onSubmit}>
                <Field label="Client">
                    <select
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
                        disabled={!clients.length}
                        value={clientId}
                        onChange={(e) => setClientId(e.target.value)}
                    >
                        <option value="">Select a client…</option>
                        {sortedClients.map((c) => (
                            <option key={c.id} value={c.id}>
                                {/* Show Owner (PetType • Breed) */}
                                {c.ownerName} — {c.petType}
                                {c.breed ? ` • ${c.breed}` : ""}
                            </option>
                        ))}
                    </select>
                </Field>

                <Field label="Visit date">
                    <input
                        type="date"
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        max={new Date().toISOString().slice(0, 10)}
                    />
                </Field>

                <Field label="Reason for visit">
                    <input
                        type="text"
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        placeholder="e.g., Vaccination, Annual checkup, Skin rash"
                    />
                </Field>

                <Field label="Notes (optional)">
            <textarea
                rows={3}
                className="w-full resize-y rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional details…"
            />
                </Field>

                <Field label="Cost (optional)">
                    <input
                        type="text"
                        inputMode="decimal"
                        className="w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        value={cost}
                        onChange={(e) => setCost(e.target.value)}
                        placeholder="e.g., 125.50"
                    />
                </Field>

                <div className="pt-2 flex items-center gap-3">
                    <button
                        type="submit"
                        disabled={saving || !clients.length}
                        className="rounded-xl bg-blue-600 px-4 py-2 font-medium text-white shadow-sm transition hover:bg-blue-700 active:scale-[0.99] disabled:opacity-60"
                    >
                        {saving ? "Saving..." : "Submit"}
                    </button>
                    <button
                        type="button"
                        onClick={() => go("menu")}
                        className="rounded-xl border px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </Shell>
    );
}

function Field({label, children}: { label: string; children: React.ReactNode }) {
    return (
        <label className="block">
            <span className="mb-1 block text-sm font-medium text-gray-700">{label}</span>
            {children}
        </label>
    );
}
