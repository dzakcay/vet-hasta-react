import type { View } from "../types";

export default function Welcome({ go }: { go: (v: View) => void }) {
    return (
        <div
            className="flex min-h-screen cursor-pointer items-center justify-center bg-blue-50"
            onClick={() => go("menu")}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") go("menu");
            }}
            aria-label="Click anywhere to get started"
        >
            <div className="text-center">
                <h1 className="text-4xl font-bold text-blue-800">Welcome to Vet Client Manager</h1>
                <p className="mt-4 text-lg text-gray-600">Click anywhere to get started</p>
            </div>
        </div>
    );
}
