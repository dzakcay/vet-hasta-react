import { useEffect, useMemo, useState } from "react";
import type { View } from "../types";
import { getClients } from "../store/localDb";

const PAGE_SIZE = 10;

export default function ListClients({ go }: { go: (v: View) => void }) {
    const [page, setPage] = useState(0);
    const [clients, setClients] = useState(() => getClients());

    // keep fresh in case another tab adds data
    useEffect(() => {
        const onStorage = (e: StorageEvent) => {
            if (e.key === "vcm.clients") setClients(getClients());
        };
        window.addEventListener("storage", onStorage);
        return () => window.removeEventListener("storage", onStorage);
    }, []);

    // sort newest first
    const sorted = useMemo(
        () => [...clients].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
        [clients]
    );

    const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
    const currentPage = Math.min(page, totalPages - 1);
    const start = currentPage * PAGE_SIZE;
    const current = sorted.slice(start, start + PAGE_SIZE);

    return (
        <div className="flex min-h-screen items-center justify-center bg-white p-4">
            <div className="w-full max-w-5xl">
                <div className="mb-4 flex items-center justify-between">
                    <h2 className="text-2xl font-semibold text-gray-900">All Clients</h2>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>Total:</span>
                        <span className="font-medium">{clients.length}</span>
                    </div>
                </div>

                {/* Empty state */}
                {sorted.length === 0 ? (
                    <div className="rounded-2xl border bg-gray-50 p-8 text-center text-gray-700">
                        No clients yet. Add your first one from the menu.
                        <div className="mt-6 flex justify-center gap-3">
                            <button
                                onClick={() => go("add-client")}
                                className="rounded-xl bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700"
                            >
                                Add new client
                            </button>
                            <button
                                onClick={() => go("menu")}
                                className="rounded-xl border px-4 py-2 text-gray-700 hover:bg-gray-100"
                            >
                                Back to menu
                            </button>
                        </div>
                    </div>
                ) : (
                    <>
                        <div className="overflow-x-auto rounded-2xl border">
                            <table className="min-w-full divide-y divide-gray-200 bg-white">
                                <thead className="bg-gray-50">
                                <tr>
                                    <Th>Owner</Th>
                                    <Th>Type</Th>
                                    <Th>Breed</Th>
                                    <Th>DOB</Th>
                                    <Th>Created</Th>
                                </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                {current.map((c) => (
                                    <tr key={c.id} className="hover:bg-gray-50">
                                        <Td className="font-medium">{c.ownerName}</Td>
                                        <Td>{c.petType}</Td>
                                        <Td>{c.breed}</Td>
                                        <Td>{formatDate(c.dob)}</Td>
                                        <Td className="text-gray-500">{formatDateTime(c.createdAt)}</Td>
                                    </tr>
                                ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Pagination */}
                        <div className="mt-4 flex items-center justify-between">
                            <button
                                onClick={() => setPage((p) => Math.max(0, p - 1))}
                                disabled={currentPage === 0}
                                className="rounded-xl border px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50"
                            >
                                Previous
                            </button>

                            <div className="text-sm text-gray-600">
                                Page <span className="font-medium">{currentPage + 1}</span> of{" "}
                                <span className="font-medium">{totalPages}</span>
                            </div>

                            <button
                                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                                disabled={currentPage >= totalPages - 1}
                                className="rounded-xl border px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50"
                            >
                                Next
                            </button>
                        </div>

                        <div className="mt-6">
                            <button
                                onClick={() => go("menu")}
                                className="rounded-xl border px-4 py-2 text-gray-700 hover:bg-gray-100"
                            >
                                Back to menu
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

function Th({ children }: { children: React.ReactNode }) {
    return (
        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
            {children}
        </th>
    );
}

function Td({
                children,
                className = "",
            }: {
    children: React.ReactNode;
    className?: string;
}) {
    return <td className={`px-4 py-3 text-sm ${className}`}>{children}</td>;
}

function formatDate(iso: string) {
    try {
        return new Date(iso).toLocaleDateString();
    } catch {
        return iso;
    }
}

function formatDateTime(iso: string) {
    try {
        const d = new Date(iso);
        return `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    } catch {
        return iso;
    }
}
