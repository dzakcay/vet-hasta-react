import type { View } from "../types";

export default function Menu({ go }: { go: (v: View) => void }) {
    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-50">
            <div className="grid w-full max-w-md gap-6">
                <div className="grid grid-cols-2 gap-4">
                    <MenuButton label="Add new client" onClick={() => go("add-client")} />
                    <MenuButton label="List all clients" onClick={() => go("list-clients")} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <MenuButton label="Add new visit" onClick={() => go("add-visit")} />
                    <MenuButton label="List all visits" onClick={() => go("list-visits")} />
                </div>
                <MenuButton label="Exit / Return to main" onClick={() => go("welcome")} variant="secondary" full />
            </div>
        </div>
    );
}

function MenuButton({
                        label,
                        onClick,
                        variant = "primary",
                        full = false,
                    }: {
    label: string;
    onClick: () => void;
    variant?: "primary" | "secondary";
    full?: boolean;
}) {
    const base =
        "rounded-xl px-4 py-3 text-center text-base font-medium shadow-sm transition active:scale-[0.99]";
    const classes =
        variant === "primary"
            ? "bg-blue-600 text-white hover:bg-blue-700"
            : "bg-white text-gray-900 border hover:bg-gray-50";
    return (
        <button onClick={onClick} className={`${base} ${classes} ${full ? "w-full" : "w-full"}`}>
            {label}
        </button>
    );
}
