import React from "react";

export default function Shell({
                                  title,
                                  subtitle,
                                  onBack,
                                  centered = false,
                                  children,
                              }: {
    title: string;
    subtitle?: string;
    onBack?: () => void;
    centered?: boolean;
    children: React.ReactNode;
}) {
    return (
        <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
            <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
                <div className="mx-auto max-w-5xl px-6 py-4 flex items-center justify-between">
                    <h1 className="text-xl font-semibold text-slate-800">{title}</h1>
                    <div className="flex items-center gap-2">
                        {onBack && (
                            <button
                                onClick={onBack}
                                className="rounded-lg border px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-50 active:scale-[0.99]"
                            >
                                Back to menu
                            </button>
                        )}
                    </div>
                </div>
                {subtitle && (
                    <div className="mx-auto max-w-5xl px-6 pb-4 text-sm text-slate-500">
                        {subtitle}
                    </div>
                )}
            </header>

            {/* Center the content under the header area */}
            <main
                className={[
                    "mx-auto max-w-5xl px-6 py-8",
                    centered ? "grid place-items-center min-h-[calc(100svh-5.5rem)] md:min-h-[calc(100svh-4.5rem)]" : "",
                ].join(" ")}
            >
                {children}
            </main>
        </div>
    );
}
